#include "myflpt.h"
#include "fractal_myflpt.h"
#include "swap.h"
#include "vga.h"
#include "cache.h"
#include <stddef.h>
#include <stdio.h>

// Constants describing the output device
const int SCREEN_WIDTH = 512;   //!< screen width
const int SCREEN_HEIGHT = 512;  //!< screen height

// Constants describing the initial view port on the fractal function
const float FRAC_WIDTH = 3.0; //!< default fractal width (3.0 in Q4.28)
const float CX_0 = -2.0 ;      //!< default start x-coordinate (-2.0 in Q4.28)
const float CY_0 = -1.5;      //!< default start y-coordinate (-1.5 in Q4.28)
const uint16_t N_MAX = 64;    //!< maximum number of iterations

int main() {
   volatile unsigned int *vga = (unsigned int *) 0x50000020;
   volatile unsigned int reg, hi;
   rgb565 frameBuffer[SCREEN_WIDTH*SCREEN_HEIGHT];
   float delta = FRAC_WIDTH / SCREEN_WIDTH;
   int i;
   vga_clear();
   printf("Starting drawing a fractal\n");
#ifdef __OR1300__   
   /* enable the caches */
   icache_write_cfg( CACHE_DIRECT_MAPPED | CACHE_SIZE_8K | CACHE_REPLACE_FIFO );
   dcache_write_cfg( CACHE_FOUR_WAY | CACHE_SIZE_8K | CACHE_REPLACE_LRU | CACHE_WRITE_BACK );
   icache_enable(1);
   dcache_enable(1);
#endif
   /* Enable the vga-controller's graphic mode */
   vga[0] = swap_u32(SCREEN_WIDTH);
   vga[1] = swap_u32(SCREEN_HEIGHT);
   vga[2] = swap_u32(1);
   vga[3] = swap_u32((unsigned int)&frameBuffer[0]);
   /* Clear screen */
   for (i = 0 ; i < SCREEN_WIDTH*SCREEN_HEIGHT ; i++) frameBuffer[i]=0;

    draw_fractal(frameBuffer,SCREEN_WIDTH,SCREEN_HEIGHT,&calc_mandelbrot_point_soft, &iter_to_colour,float_to_myft(CX_0),float_to_myft(CY_0),float_to_myft(delta),N_MAX);
   /* 
   myft a =float_to_myft(CX_0);
   printf("a:  s=%u  e=%u  m=%u \n",
           myft_sign(a), myft_exp(a), myft_mantissa(a));
   print_myft_decimal(a);
   myft b =float_to_myft(CY_0);
   printf("b:  s=%u  e=%u  m=%u \n",
           myft_sign(b), myft_exp(b), myft_mantissa(b));
   print_myft_decimal(b);
   myft d =float_to_myft(delta);
   printf("d:  s=%u  e=%u  m=%u \n",
           myft_sign(d), myft_exp(d), myft_mantissa(d));
   print_myft_decimal( d);
   print_myft_decimal( myft_add(a,b));

   print_myft_decimal( myft_sub(a,b));

   print_myft_decimal( myft_mul(a,b));

   printf("%d \n",myft_cmp(a,b));


   myft xx = myft_mul(a,a), yy = myft_mul(b,b);
   myft r2 = myft_add(xx,yy);
   print_myft_decimal(r2);  
   */
#ifdef __OR1300__
   dcache_flush();
#endif
   printf("Done\n");
}