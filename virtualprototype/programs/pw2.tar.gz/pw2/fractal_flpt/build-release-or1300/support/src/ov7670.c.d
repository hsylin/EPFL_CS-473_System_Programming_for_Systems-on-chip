build-release-or1300/support/src/ov7670.c.o: support/src/ov7670.c \
 support/include/ov7670.h support/include/stdint.h \
 support/include/delay.h
